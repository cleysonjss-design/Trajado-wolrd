extends CharacterBody3D

const SPEED := 7.0
const JUMP := 7.0
var gravity := 18.0

func _ready():
    var mesh = MeshInstance3D.new()
    var capsule = CapsuleMesh.new()
    capsule.height = 2.0
    capsule.radius = 0.55
    mesh.mesh = capsule
    var mat = StandardMaterial3D.new()
    mat.albedo_color = Color("#3b6ee8")
    mesh.material_override = mat
    mesh.position.y = 1.0
    add_child(mesh)

    var collision = CollisionShape3D.new()
    var shape = CapsuleShape3D.new()
    shape.height = 2.0
    shape.radius = 0.55
    collision.shape = shape
    collision.position.y = 1.0
    add_child(collision)

func _physics_process(delta):
    if not is_multiplayer_authority():
        return
    var input = Input.get_vector("move_left", "move_right", "move_forward", "move_back")
    var dir = Vector3(input.x, 0, input.y)
    velocity.x = dir.x * SPEED
    velocity.z = dir.z * SPEED
    if not is_on_floor():
        velocity.y -= gravity * delta
    elif Input.is_action_just_pressed("jump"):
        velocity.y = JUMP
    move_and_slide()
