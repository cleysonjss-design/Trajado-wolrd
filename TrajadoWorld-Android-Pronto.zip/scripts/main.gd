extends Node3D

const PORT := 7777
const MAX_PLAYERS := 30
var players := {}
var player_scene := preload("res://scripts/player.gd")

var lobby: Control
var status_label: Label
var room_code := ""

func _ready():
    _build_world()
    _build_lobby()

func _build_world():
    var env = WorldEnvironment.new()
    var environment = Environment.new()
    environment.background_mode = Environment.BG_COLOR
    environment.background_color = Color("#86b9e8")
    environment.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    environment.ambient_light_color = Color.WHITE
    environment.ambient_light_energy = 0.8
    env.environment = environment
    add_child(env)

    var sun = DirectionalLight3D.new()
    sun.rotation_degrees = Vector3(-55, -25, 0)
    sun.light_energy = 1.2
    add_child(sun)

    var ground = MeshInstance3D.new()
    var box = BoxMesh.new()
    box.size = Vector3(120, 1, 120)
    ground.mesh = box
    ground.position.y = -0.5
    var mat = StandardMaterial3D.new()
    mat.albedo_color = Color("#4f8f4b")
    ground.material_override = mat
    add_child(ground)

    for i in range(14):
        var building = MeshInstance3D.new()
        var bm = BoxMesh.new()
        bm.size = Vector3(8 + (i%3)*3, 5 + (i%2)*2, 8)
        building.mesh = bm
        building.position = Vector3(-45 + (i%7)*15, bm.size.y/2, -25 + (i/7)*45)
        var bmat = StandardMaterial3D.new()
        bmat.albedo_color = Color.from_hsv(float(i)/14.0, 0.28, 0.72)
        building.material_override = bmat
        add_child(building)

    var camera = Camera3D.new()
    camera.position = Vector3(0, 18, 25)
    camera.rotation_degrees = Vector3(-28, 0, 0)
    camera.current = true
    add_child(camera)

func _build_lobby():
    lobby = Control.new()
    lobby.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    add_child(lobby)

    var panel = ColorRect.new()
    panel.color = Color(0.03,0.04,0.06,0.92)
    panel.position = Vector2(30,30)
    panel.size = Vector2(390, 390)
    lobby.add_child(panel)

    var title = Label.new()
    title.text = "TRAJADO WORLD"
    title.position = Vector2(60,55)
    title.add_theme_font_size_override("font_size", 30)
    lobby.add_child(title)

    var subtitle = Label.new()
    subtitle.text = "Mundo aberto • até 30 jogadores"
    subtitle.position = Vector2(62,98)
    lobby.add_child(subtitle)

    var host = Button.new()
    host.text = "CRIAR SALA"
    host.position = Vector2(60,145)
    host.size = Vector2(320,55)
    host.pressed.connect(_host_game)
    lobby.add_child(host)

    var code = LineEdit.new()
    code.name = "Code"
    code.placeholder_text = "Código da sala (ex.: ABC123)"
    code.position = Vector2(60,215)
    code.size = Vector2(320,45)
    lobby.add_child(code)

    var join = Button.new()
    join.text = "ENTRAR NA SALA"
    join.position = Vector2(60,275)
    join.size = Vector2(320,55)
    join.pressed.connect(func(): _join_game(code.text))
    lobby.add_child(join)

    status_label = Label.new()
    status_label.text = "Offline • escolha uma opção"
    status_label.position = Vector2(60,345)
    lobby.add_child(status_label)

func _host_game():
    var peer = ENetMultiplayerPeer.new()
    var err = peer.create_server(PORT, MAX_PLAYERS)
    if err != OK:
        status_label.text = "Erro ao criar servidor: %s" % err
        return
    multiplayer.multiplayer_peer = peer
    room_code = _make_code()
    status_label.text = "Sala criada: %s\nIP para amigos: seu-IP:%d" % [room_code, PORT]
    lobby.visible = false
    _spawn_player(multiplayer.get_unique_id())

func _join_game(code: String):
    if code.strip_edges().is_empty():
        status_label.text = "Digite o código da sala."
        return
    var ip = "127.0.0.1"
    var peer = ENetMultiplayerPeer.new()
    var err = peer.create_client(ip, PORT)
    if err != OK:
        status_label.text = "Erro de conexão: %s" % err
        return
    multiplayer.multiplayer_peer = peer
    status_label.text = "Conectando à sala %s..." % code
    lobby.visible = false

func _spawn_player(id: int):
    if players.has(id): return
    var p = CharacterBody3D.new()
    p.set_script(player_scene)
    p.name = "Player_%s" % id
    p.position = Vector3((id % 5) * 3 - 6, 2, (id % 6) * 3 - 8)
    add_child(p)
    players[id] = p

func _make_code() -> String:
    var chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
    var out = ""
    for i in range(6):
        out += chars[randi() % chars.length()]
    return out
